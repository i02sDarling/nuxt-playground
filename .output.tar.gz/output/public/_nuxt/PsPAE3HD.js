const e={startingFile:"pages/index.vue",features:{fileTree:!0}};e.files={"pages/foo.vue":`<template>\r
  <div>\r
    Foo\r
    <div>\r
      <NuxtLink to="/">\r
        Index\r
      </NuxtLink>\r
    </div>\r
  </div>\r
</template>\r
`,"app.vue":`<template>\r
  <NuxtPage />\r
</template>\r
`,"pages/index.vue":`<template>\r
  <div>\r
    Hello!\r
    <div>\r
      <NuxtLink to="/foo">\r
        Foo\r
      </NuxtLink>\r
    </div>\r
  </div>\r
</template>\r
`};e.solutions=void 0;export{e as meta};
