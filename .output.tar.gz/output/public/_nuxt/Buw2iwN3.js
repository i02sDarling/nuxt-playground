import{e as n,O as e}from"./D3peE3eq.js";const t=n({name:"DocumentDrivenNotFound",render(){return e("div","Document not found")}});export{t as default};
