const e={startingFile:"app.vue",features:{terminal:!1,fileTree:!1}};e.files={"app.vue":`<script setup lang="ts">\r
const msg = 'INDEX PAGE'\r
<\/script>\r
\r
<template>\r
  <div>{{ msg.toUpperCase() }}</div>\r
</template>\r
`};e.solutions={"app.vue":`<script setup lang="ts">\r
const msg = 'This is the solution!'\r
<\/script>\r
\r
<template>\r
  <div>{{ msg.toUpperCase() }}</div>\r
</template>\r
`};export{e as meta};
