import{_ as o}from"./D3peE3eq.js";const _={basic:t=>o(()=>import("./BIXrYaYJ.js"),[],import.meta.url).then(e=>e.default(t))};export{_ as templates};
