const t={startingFile:"app.vue"};t.files={"app.vue":`<script setup lang="ts">\r
const msg = 'Hello World!'\r
<\/script>\r
\r
<template>\r
  <div>{{ msg.toUpperCase() }}</div>\r
</template>\r
`};t.solutions=void 0;export{t as meta};
