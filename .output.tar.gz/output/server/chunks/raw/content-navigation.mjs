// ROLLUP_NO_REPLACE 
 const contentNavigation = "[{\"title\":\"Vue\",\"_path\":\"/vue\",\"children\":[{\"title\":\"Vue Basic\",\"_path\":\"/vue/intro\",\"children\":[{\"title\":\"Vue Basic\",\"_path\":\"/vue/intro\"}]}]},{\"title\":\"Concepts\",\"_path\":\"/concepts\",\"children\":[{\"title\":\"Nuxt Concepts\",\"_path\":\"/concepts/intro\",\"children\":[{\"title\":\"Nuxt Concepts\",\"_path\":\"/concepts/intro\"}]},{\"title\":\"App.vue\",\"_path\":\"/concepts/app-vue\",\"children\":[{\"title\":\"App.vue\",\"_path\":\"/concepts/app-vue\"}]},{\"title\":\"Components\",\"_path\":\"/concepts/components\",\"children\":[{\"title\":\"Components\",\"_path\":\"/concepts/components\"}]},{\"title\":\"Routing\",\"_path\":\"/concepts/routing\",\"children\":[{\"title\":\"Routing\",\"_path\":\"/concepts/routing\"}]}]},{\"title\":\"Welcome to Nuxt Tutorial!\",\"_path\":\"/\"}]";

export { contentNavigation as default };
//# sourceMappingURL=content-navigation.mjs.map
