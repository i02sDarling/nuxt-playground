// ROLLUP_NO_REPLACE 
 const index = "{\"parsed\":{\"_path\":\"/concepts/components\",\"_dir\":\"concepts\",\"_draft\":false,\"_partial\":false,\"_locale\":\"\",\"title\":\"Components\",\"description\":\"\",\"body\":{\"type\":\"root\",\"children\":[{\"type\":\"element\",\"tag\":\"h1\",\"props\":{\"id\":\"components\"},\"children\":[{\"type\":\"text\",\"value\":\"Components\"}]}],\"toc\":{\"title\":\"\",\"searchDepth\":2,\"depth\":2,\"links\":[]}},\"_type\":\"markdown\",\"_id\":\"content:2.concepts:3.components:index.md\",\"_source\":\"content\",\"_file\":\"2.concepts/3.components/index.md\",\"_extension\":\"md\"},\"hash\":\"YbIxg7pGIw\"}";

export { index as default };
//# sourceMappingURL=index5.mjs.map
