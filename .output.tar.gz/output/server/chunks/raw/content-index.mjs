// ROLLUP_NO_REPLACE 
 const contentIndex = "{\"/\":[\"content:index.md\"],\"/vue/intro\":[\"content:1.vue:1.intro:index.md\"],\"/concepts/intro\":[\"content:2.concepts:1.intro:index.md\"],\"/concepts/components\":[\"content:2.concepts:3.components:index.md\"],\"/concepts/app-vue\":[\"content:2.concepts:2.app-vue:index.md\"],\"/concepts/routing\":[\"content:2.concepts:3.routing:index.md\"]}";

export { contentIndex as default };
//# sourceMappingURL=content-index.mjs.map
