// ROLLUP_NO_REPLACE 
 const index = "{\"parsed\":{\"_path\":\"/concepts/app-vue\",\"_dir\":\"concepts\",\"_draft\":false,\"_partial\":false,\"_locale\":\"\",\"title\":\"App.vue\",\"description\":\"Back to index\",\"body\":{\"type\":\"root\",\"children\":[{\"type\":\"element\",\"tag\":\"h1\",\"props\":{\"id\":\"appvue\"},\"children\":[{\"type\":\"text\",\"value\":\"App.vue\"}]},{\"type\":\"element\",\"tag\":\"p\",\"props\":{},\"children\":[{\"type\":\"element\",\"tag\":\"a\",\"props\":{\"href\":\"/\"},\"children\":[{\"type\":\"text\",\"value\":\"Back to index\"}]}]}],\"toc\":{\"title\":\"\",\"searchDepth\":2,\"depth\":2,\"links\":[]}},\"_type\":\"markdown\",\"_id\":\"content:2.concepts:2.app-vue:index.md\",\"_source\":\"content\",\"_file\":\"2.concepts/2.app-vue/index.md\",\"_extension\":\"md\"},\"hash\":\"hSmmFUJ4Ix\"}";

export { index as default };
//# sourceMappingURL=index4.mjs.map
