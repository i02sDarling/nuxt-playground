// ROLLUP_NO_REPLACE 
 const index = "{\"parsed\":{\"_path\":\"/concepts/routing\",\"_dir\":\"concepts\",\"_draft\":false,\"_partial\":false,\"_locale\":\"\",\"title\":\"Routing\",\"description\":\"Back to index\",\"body\":{\"type\":\"root\",\"children\":[{\"type\":\"element\",\"tag\":\"h1\",\"props\":{\"id\":\"routing\"},\"children\":[{\"type\":\"text\",\"value\":\"Routing\"}]},{\"type\":\"element\",\"tag\":\"p\",\"props\":{},\"children\":[{\"type\":\"element\",\"tag\":\"a\",\"props\":{\"href\":\"/\"},\"children\":[{\"type\":\"text\",\"value\":\"Back to index\"}]}]}],\"toc\":{\"title\":\"\",\"searchDepth\":2,\"depth\":2,\"links\":[]}},\"_type\":\"markdown\",\"_id\":\"content:2.concepts:3.routing:index.md\",\"_source\":\"content\",\"_file\":\"2.concepts/3.routing/index.md\",\"_extension\":\"md\"},\"hash\":\"5YK2vjo6Z3\"}";

export { index as default };
//# sourceMappingURL=index6.mjs.map
